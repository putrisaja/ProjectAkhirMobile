package com.putri.projectakhirmobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class Note implements Parcelable {
private int id;
private String nama_kopi;
private String asal_kopi;
private String harga;
private String deskripsi;
private String date;

public Note(int id, String nama_kopi, String asal_kopi, String harga, String deskripsi, String date){
    this.id = id;
    this.nama_kopi = nama_kopi;
    this.asal_kopi = asal_kopi;
    this.harga = harga;
    this.deskripsi = deskripsi;
    this.date = date;
}

public Note(){}

protected Note(Parcel in) {
    id = in.readInt();
    nama_kopi = in.readString();
    asal_kopi = in.readString();
    harga = in.readString();
    deskripsi = in.readString();
    date = in.readString();
}

public static final Creator<Note> CREATOR = new Creator<Note>() {
@Override
public Note createFromParcel(Parcel in) {
return new Note(in);
}

@Override
public Note[] newArray(int size) {
return new Note[size];
}
};

public int getId() {
return id;
}

public void setId(int id) {
this.id = id;
}

public String getNamaKopi() {
return nama_kopi;
}

public void setNamakopi(String nama_kopi) {
this.nama_kopi = nama_kopi;
}

public String getHarga() {
return harga;
}

public void setHarga(String harga) {
this.harga = harga;
}

    public String getAsalKopi() {
        return asal_kopi;
    }

    public void setAsalKopi(String asal_kopi) {
        this.asal_kopi = asal_kopi;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

public String getDate() {
return date;
}

public void setDate(String date) {
this.date = date;
}

@Override
public int describeContents() {
return 0;
}

@Override
public void writeToParcel(Parcel parcel, int i) {
    parcel.writeInt(id);
    parcel.writeString(nama_kopi);
    parcel.writeString(asal_kopi);
    parcel.writeString(harga);
    parcel.writeString(deskripsi);
    parcel.writeString(date);
}
}