package com.putri.projectakhirmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
EditText etEmail, etPassword;
Button btLogin;

@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_login);

etEmail = findViewById(R.id.et_email);
etPassword = findViewById(R.id.et_password);
btLogin = findViewById(R.id.bt_login);
}

public void login_action(View view) {
if (etEmail.getText().toString().equals("putrinadirajuga@gmail.com") && etPassword.getText().toString().equals("181051030")) {
Toast ToastSukses = Toast.makeText(this, "Login Sukses", Toast.LENGTH_SHORT);
ToastSukses.show();
Intent showIntent = new Intent(this, MainActivity.class);
startActivity(showIntent);
}
else{
Toast ToastError = Toast.makeText(this,"Login Gagal, Email atau Kata sandi salah!", Toast.LENGTH_SHORT);
ToastError.show();
}
}
}
