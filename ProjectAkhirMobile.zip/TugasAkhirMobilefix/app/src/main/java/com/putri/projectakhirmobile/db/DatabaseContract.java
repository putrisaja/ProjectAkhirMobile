package com.putri.projectakhirmobile.db;

import android.provider.BaseColumns;

public class DatabaseContract {
static String TABLE_NAME = "kopi";

public static final class NoteColumns implements BaseColumns {
public static String NAMA_KOPI = "nama_kopi";
public static String ASAL_KOPI = "asal_kopi";
public static String HARGA = "harga";
public static String DESKIPSI = "deskripsi";
public static String DATE = "date";
}
}
